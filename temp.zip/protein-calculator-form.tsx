"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { AffiliateBridge } from "@/components/landing/affiliate-bridge"
import { type Goal, proteinTarget } from "@/lib/calculators"

export function ProteinCalculatorForm() {
  const [weightKg, setWeightKg] = useState("")
  const [goal, setGoal] = useState<Goal>("lose")
  const [result, setResult] = useState<number | null>(null)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!weightKg) return
    setResult(proteinTarget(Number(weightKg), goal))
  }

  return (
    <div className="rounded-2xl border border-[#0F1B2A]/10 bg-white p-6 shadow-sm md:p-8">
      {result === null ? (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label htmlFor="weight">Weight (kg)</Label>
            <Input id="weight" type="number" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} placeholder="72" />
          </div>
          <div>
            <Label>Goal</Label>
            <Select value={goal} onValueChange={(v) => setGoal(v as Goal)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="lose">Lose fat (preserve muscle)</SelectItem>
                <SelectItem value="maintain">Maintain</SelectItem>
                <SelectItem value="gain">Build muscle</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full rounded-full bg-[#0E7C7B] py-6 text-base font-medium text-white hover:bg-[#0E7C7B]/90">
            Calculate Protein Target
          </Button>
        </form>
      ) : (
        <div className="space-y-6 text-center">
          <div>
            <p className="font-mono text-5xl text-[#0F1B2A]">{result}g</p>
            <p className="mt-2 text-sm text-[#0F1B2A]/50">recommended protein per day</p>
          </div>
          <AffiliateBridge />
          <button onClick={() => setResult(null)} className="text-sm text-[#0F1B2A]/50 underline underline-offset-4">
            Recalculate
          </button>
        </div>
      )}
    </div>
  )
}
