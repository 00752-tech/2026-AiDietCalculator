"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { AffiliateBridge } from "@/components/landing/affiliate-bridge"
import { type Sex, bmr as calcBmr } from "@/lib/calculators"

export function BmrCalculatorForm() {
  const [sex, setSex] = useState<Sex>("female")
  const [age, setAge] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [weightKg, setWeightKg] = useState("")
  const [result, setResult] = useState<number | null>(null)

  const canSubmit = age && heightCm && weightKg

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!canSubmit) return
    setResult(calcBmr(sex, Number(weightKg), Number(heightCm), Number(age)))
  }

  return (
    <div className="rounded-2xl border border-[#0F1B2A]/10 bg-white p-6 shadow-sm md:p-8">
      {result === null ? (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="age">Age</Label>
              <Input id="age" type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="18" />
            </div>
            <div>
              <Label>Sex</Label>
              <Select value={sex} onValueChange={(v) => setSex(v as Sex)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="height">Height (cm)</Label>
              <Input id="height" type="number" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} placeholder="169" />
            </div>
            <div>
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input id="weight" type="number" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} placeholder="69.5" />
            </div>
          </div>
          <Button type="submit" className="w-full rounded-full bg-[#0E7C7B] py-6 text-base font-medium text-white hover:bg-[#0E7C7B]/90">
            Calculate BMR
          </Button>
        </form>
      ) : (
        <div className="space-y-6 text-center">
          <div>
            <p className="font-mono text-5xl text-[#0F1B2A]">{result}</p>
            <p className="mt-2 text-sm text-[#0F1B2A]/50">kcal/day at complete rest (Mifflin-St Jeor)</p>
          </div>
          <AffiliateBridge />
          <button onClick={() => setResult(null)} className="text-sm text-[#0F1B2A]/50 underline underline-offset-4">
            Recalculate
          </button>
        </div>
      )}
    </div>
  )
}
