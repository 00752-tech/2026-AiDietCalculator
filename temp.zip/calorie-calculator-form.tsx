"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { AffiliateBridge } from "@/components/landing/affiliate-bridge"
import {
  type Sex,
  type Activity,
  type Goal,
  ACTIVITY_LABELS,
  bmr as calcBmr,
  tdee as calcTdee,
  calorieTarget,
} from "@/lib/calculators"

export function CalorieCalculatorForm() {
  const [sex, setSex] = useState<Sex>("female")
  const [age, setAge] = useState("")
  const [heightCm, setHeightCm] = useState("")
  const [weightKg, setWeightKg] = useState("")
  const [activity, setActivity] = useState<Activity>("light")
  const [goal, setGoal] = useState<Goal>("lose")
  const [result, setResult] = useState<{ tdee: number; target: number } | null>(null)

  const canSubmit = age && heightCm && weightKg

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!canSubmit) return
    const bmrValue = calcBmr(sex, Number(weightKg), Number(heightCm), Number(age))
    const tdeeValue = calcTdee(bmrValue, activity)
    setResult({ tdee: tdeeValue, target: calorieTarget(tdeeValue, goal) })
  }

  return (
    <div className="rounded-2xl border border-[#0F1B2A]/10 bg-white p-6 shadow-sm md:p-8">
      {!result ? (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="age">Age</Label>
              <Input id="age" type="number" value={age} onChange={(e) => setAge(e.target.value)} placeholder="42" />
            </div>
            <div>
              <Label>Sex</Label>
              <Select value={sex} onValueChange={(v) => setSex(v as Sex)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="female">Female</SelectItem>
                  <SelectItem value="male">Male</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="height">Height (cm)</Label>
              <Input id="height" type="number" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} placeholder="165" />
            </div>
            <div>
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input id="weight" type="number" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} placeholder="72" />
            </div>
          </div>
          <div>
            <Label>Activity level</Label>
            <Select value={activity} onValueChange={(v) => setActivity(v as Activity)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(Object.keys(ACTIVITY_LABELS) as Activity[]).map((key) => (
                  <SelectItem key={key} value={key}>{ACTIVITY_LABELS[key]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label>Goal</Label>
            <Select value={goal} onValueChange={(v) => setGoal(v as Goal)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="lose">Lose weight</SelectItem>
                <SelectItem value="maintain">Maintain weight</SelectItem>
                <SelectItem value="gain">Gain weight</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button type="submit" className="w-full rounded-full bg-[#0E7C7B] py-6 text-base font-medium text-white hover:bg-[#0E7C7B]/90">
            Calculate Calories
          </Button>
        </form>
      ) : (
        <div className="space-y-6 text-center">
          <div className="rounded-xl bg-[#0F1B2A] p-6 font-mono text-white">
            <div className="flex items-baseline justify-between border-b border-white/10 py-3">
              <span className="text-xs uppercase tracking-wide text-white/50">Maintenance calories</span>
              <span className="text-sm">{result.tdee} kcal/day</span>
            </div>
            <div className="flex items-baseline justify-between py-3">
              <span className="text-xs uppercase tracking-wide text-white/50">Your target</span>
              <span className="text-lg text-[#4FD1D0]">{result.target} kcal/day</span>
            </div>
          </div>
          <AffiliateBridge />
          <button onClick={() => setResult(null)} className="text-sm text-[#0F1B2A]/50 underline underline-offset-4">
            Recalculate
          </button>
        </div>
      )}
    </div>
  )
}
