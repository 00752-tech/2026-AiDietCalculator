"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AffiliateBridge } from "@/components/landing/affiliate-bridge"
import { bmi, bmiCategory } from "@/lib/calculators"

export function BmiCalculatorForm() {
  const [heightCm, setHeightCm] = useState("")
  const [weightKg, setWeightKg] = useState("")
  const [result, setResult] = useState<{ value: number; label: string; color: string } | null>(null)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!heightCm || !weightKg) return
    const value = bmi(Number(weightKg), Number(heightCm))
    setResult({ value, ...bmiCategory(value) })
  }

  return (
    <div className="rounded-2xl border border-[#0F1B2A]/10 bg-white p-6 shadow-sm md:p-8">
      {!result ? (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="height">Height (cm)</Label>
              <Input id="height" type="number" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} placeholder="165" />
            </div>
            <div>
              <Label htmlFor="weight">Weight (kg)</Label>
              <Input id="weight" type="number" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} placeholder="68" />
            </div>
          </div>
          <Button type="submit" className="w-full rounded-full bg-[#0E7C7B] py-6 text-base font-medium text-white hover:bg-[#0E7C7B]/90">
            Calculate BMI
          </Button>
        </form>
      ) : (
        <div className="space-y-6 text-center">
          <div>
            <p className="font-mono text-5xl text-[#0F1B2A]">{result.value}</p>
            <p className="mt-2 font-mono text-sm uppercase tracking-wide" style={{ color: result.color }}>
              {result.label}
            </p>
          </div>
          <p className="text-xs text-[#0F1B2A]/50">
            BMI doesn&apos;t account for muscle mass or frame size — it&apos;s a starting point, not a diagnosis.
          </p>
          <AffiliateBridge
            headline="BMI is a snapshot. What you do next matters more."
            body="If your number came back higher than you'd like, see the daily formula built to support consistent, sustainable results."
          />
          <button onClick={() => setResult(null)} className="text-sm text-[#0F1B2A]/50 underline underline-offset-4">
            Recalculate
          </button>
        </div>
      )}
    </div>
  )
}
