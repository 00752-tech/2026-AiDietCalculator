"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { AffiliateBridge } from "@/components/landing/affiliate-bridge"
import { type Sex, idealWeightKg } from "@/lib/calculators"

export function IdealWeightCalculatorForm() {
  const [sex, setSex] = useState<Sex>("female")
  const [heightCm, setHeightCm] = useState("")
  const [result, setResult] = useState<number | null>(null)

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    if (!heightCm) return
    setResult(idealWeightKg(sex, Number(heightCm)))
  }

  return (
    <div className="rounded-2xl border border-[#0F1B2A]/10 bg-white p-6 shadow-sm md:p-8">
      {result === null ? (
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <Label>Sex</Label>
            <Select value={sex} onValueChange={(v) => setSex(v as Sex)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="female">Female</SelectItem>
                <SelectItem value="male">Male</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="height">Height (cm)</Label>
            <Input id="height" type="number" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} placeholder="178" />
          </div>
          <Button type="submit" className="w-full rounded-full bg-[#0E7C7B] py-6 text-base font-medium text-white hover:bg-[#0E7C7B]/90">
            Calculate Ideal Weight
          </Button>
        </form>
      ) : (
        <div className="space-y-6 text-center">
          <div>
            <p className="font-mono text-5xl text-[#0F1B2A]">{result} kg</p>
            <p className="mt-2 text-sm text-[#0F1B2A]/50">estimated ideal weight (Devine formula)</p>
          </div>
          <AffiliateBridge />
          <button onClick={() => setResult(null)} className="text-sm text-[#0F1B2A]/50 underline underline-offset-4">
            Recalculate
          </button>
        </div>
      )}
    </div>
  )
}
